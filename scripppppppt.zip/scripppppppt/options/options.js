document.addEventListener('DOMContentLoaded', () => {
    const features = ['kururing', 'randomSearch', 'rickImage', 'rickLink'];

    // 설정값 로드
    chrome.storage.sync.get(features, (data) => {
        features.forEach(feature => {
            const checkbox = document.getElementById(feature);
            if (checkbox) {
                checkbox.checked = data[feature] || false;
            }
        });
    });

    // 체크박스 변경 시 저장
    features.forEach(feature => {
        const checkbox = document.getElementById(feature);
        if (checkbox) {
            checkbox.addEventListener('change', (event) => {
                chrome.storage.sync.set({ [feature]: event.target.checked }, () => {
                    console.log(`${feature} 설정이 저장됨: ${event.target.checked}`);
                });
            });
        }
    });
});
