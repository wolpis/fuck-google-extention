const features = ['kururing', 'randomSearch', 'rickImage', 'rickLink'];

const actions = {
    kururing: { on: activateKururing, off: deactivateKururing },
    randomSearch: { on: activateRandomSearch, off: deactivateRandomSearch },
    rickImage: { on: activateRickImage, off: deactivateRickImage },
    rickLink: { on: activateRickLink, off: deactivateRickLink },
};

// 초기 적용
chrome.storage.sync.get(features, (data) => {
    features.forEach(feature => {
        if (data[feature]) actions[feature].on();
    });
});

// 변경 실시간 적용
chrome.storage.onChanged.addListener((changes) => {
    for (let [feature, { newValue }] of Object.entries(changes)) {
        if (newValue) {
            actions[feature].on();
        } else {
            actions[feature].off();
        }
    }
});
